"""GMbot direct-audio URL resolver for ESP32 (Render edition).

Finds supported direct audio URLs. No HLS proxying, no cookies, no downloads.
The API is independently implemented for a clean deployment and is not a copy
of the upstream DUONGBOT backend.
"""

import logging
import os
import secrets
from typing import Any
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, Header, HTTPException, Query
import yt_dlp

log = logging.getLogger("gmbot.music")
logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))

app = FastAPI(title="GMbot Direct Music Resolver", version="1.0.0", docs_url=None, redoc_url=None)

# Supported by the future ESP32 direct player. MP3 works first; M4A/AAC requires
# proper container decoding in the firmware and must NOT go to the MP3 decoder.
SUPPORTED_EXT = {"mp3", "m4a", "aac"}
MAX_RESULTS_SC = 5


def require_api_key(x_api_key: str | None = Header(default=None)) -> None:
    expected = os.environ.get("MUSIC_API_KEY", "")
    if not expected:
        raise HTTPException(status_code=503, detail="MUSIC_API_KEY not configured")
    if not x_api_key or not secrets.compare_digest(x_api_key, expected):
        raise HTTPException(status_code=401, detail="Invalid API key")


def is_progressive_audio(fmt: dict[str, Any]) -> bool:
    url = fmt.get("url") or ""
    ext = str(fmt.get("ext") or "").lower()
    protocol = str(fmt.get("protocol") or "").lower()
    codec = str(fmt.get("acodec") or "").lower()
    video = str(fmt.get("vcodec") or "none").lower()
    if not url.startswith(("https://", "http://")):
        return False
    if ext not in SUPPORTED_EXT:
        return False
    if codec in {"none", "unknown"} or video not in {"none", ""}:
        return False
    if fmt.get("has_drm"):
        return False
    # yt-dlp sometimes labels HLS as m4a: do not send a manifest to ESP32.
    if any(x in protocol for x in ("m3u8", "hls", "dash", "f4m", "rtmp")):
        return False
    # URL path only (don't reject valid query parameters containing these words).
    path = urlsplit(url).path.lower()
    if path.endswith((".m3u8", ".mpd", ".f4m")):
        return False
    return True


def rank(fmt: dict[str, Any]) -> tuple[int, float]:
    ext = str(fmt.get("ext") or "").lower()
    score = 100 if ext == "mp3" else 80 if ext in ("aac", "m4a") else 0
    try:
        bitrate = float(fmt.get("abr") or fmt.get("tbr") or 128)
    except (ValueError, TypeError):
        bitrate = 128
    # Moderate bitrates are generally easier for ESP32 to buffer reliably.
    if 64 <= bitrate <= 160:
        score += 30
    elif bitrate < 64:
        score += 10
    elif bitrate > 320:
        score -= 10
    return (score, bitrate)


def find_format(entry: dict[str, Any]) -> dict[str, Any] | None:
    formats = entry.get("formats") or []
    candidates = [f for f in formats if is_progressive_audio(f)]
    if not candidates and is_progressive_audio(entry):
        candidates = [entry]
    return max(candidates, key=rank) if candidates else None


def safe_headers(entry: dict[str, Any], fmt: dict[str, Any]) -> dict[str, str]:
    """Only pass benign playback headers; never expose session credentials."""
    raw = {**(entry.get("http_headers") or {}), **(fmt.get("http_headers") or {})}
    return {name: str(raw[name]) for name in ("User-Agent", "Referer", "Origin")
            if isinstance(raw.get(name), str)}


def resolve(query: str) -> dict[str, Any] | None:
    sources = (
        ("youtube", f"ytsearch1:{query}", {
            "extractor_args": {"youtube": {"player_client": ["tv_embedded", "tv", "ios"]}},
        }),
        ("soundcloud", f"scsearch{MAX_RESULTS_SC}:{query}", {}),
    )
    for source, search, extras in sources:
        options = {
            "format": "bestaudio/best",
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
            "socket_timeout": 12,
            "retries": 1,
            "extractor_retries": 1,
            **extras,
        }
        try:
            with yt_dlp.YoutubeDL(options) as downloader:
                results = downloader.extract_info(search, download=False)
            if not results:
                continue
            entries = results.get("entries") or [results]
            for entry in entries:
                if not entry:
                    continue
                fmt = find_format(entry)
                if not fmt:
                    continue
                return {
                    "source": source,
                    "title": entry.get("title") or query,
                    "id": entry.get("id"),
                    "duration": entry.get("duration"),
                    "ext": str(fmt.get("ext") or "").lower(),
                    "codec": fmt.get("acodec"),
                    "bitrate_kbps": fmt.get("abr") or fmt.get("tbr"),
                    "stream_type": "direct_progressive",
                    "url": fmt["url"],
                    "headers": safe_headers(entry, fmt),
                }
        except Exception as exc:
            # Never log extracted URLs, cookies, or signed query parameters.
            log.warning("%s extraction failed (%s)", source, type(exc).__name__)
    return None


@app.get("/")
@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "gmbot-music-resolver", "mode": "direct-only"}


@app.get("/play", dependencies=[Depends(require_api_key)])
def play(q: str = Query(min_length=1, max_length=160)) -> dict[str, Any]:
    result = resolve(q.strip())
    if result is None:
        # Firmware should immediately fall back to existing mini-PC music router.
        raise HTTPException(status_code=404, detail="No compatible direct audio URL")
    return {"status": "success", "data": result}
