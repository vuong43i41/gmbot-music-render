# GMbot Music Resolver — Render (direct first)

Một API riêng cho ESP32 Xingzhi Cube: dùng yt-dlp tìm audio URL YouTube,
không có URL phù hợp thì thử SoundCloud. **Không tải hoặc proxy âm thanh**.
Firmware ESP32 sẽ thử tải URL trực tiếp, nếu lỗi sẽ fallback sang Music Router
YouTube/Zing trên mini PC hiện có.

Được viết lại độc lập theo ý tưởng của repo tham khảo:
https://github.com/nguyendoanduong1983-hash/xiaozhi-music-api

## Bảo mật

- Không sao chép hoặc nạp `cookies.txt` từ repo tham khảo.
- Không có `/stream?m3u8=` (proxy URL tùy ý nguy hiểm), `/debug` hay `/redirect`.
- `/play` yêu cầu header `X-API-Key` khớp biến môi trường `MUSIC_API_KEY`.
- Không đưa API key vào GitHub, commit hoặc URL truy vấn.
- Key gắn vào firmware có thể được đọc từ thiết bị; dùng key riêng và có thể đổi được.

## Triển khai

1. Giải nén ZIP, tạo repository GitHub mới **thuộc tài khoản của bạn**, upload
   các file này. Không fork repo gốc để tránh giữ lại cookie trong Git history.
2. Render Dashboard > New > Web Service > kết nối GitHub > chọn repo mới.
3. Chọn `Free`, `Singapore`, `Python 3`, branch `main`.
4. Build command: `pip install -r requirements.txt`.
5. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`.
6. Environment: `MUSIC_API_KEY` = một chuỗi bí mật dài, ngẫu nhiên, tự tạo;
   `PYTHON_VERSION` = `3.11.9`.
7. Deploy; Render cấp URL `https://<ten-service>.onrender.com`.

Nếu dùng Blueprint (New > Blueprint), `render.yaml` cũng mô tả dịch vụ;
`MUSIC_API_KEY` được khai báo `sync: false` để nhập bí mật qua giao diện.

## Kiểm tra

Health check (không cần key):

```bash
curl https://<service>.onrender.com/health
```

Thử bài hát (trong PowerShell; thay tên miền và key thực):

```powershell
$env:MUSIC_API_KEY = 'KEY_BI_MAT_CUA_BAN'
curl.exe -H "X-API-Key: $env:MUSIC_API_KEY" "https://<service>.onrender.com/play?q=Lac%20Troi"
```

Trả về `status:success` và trường `data.url` nếu có URL phù hợp.
Khi không tìm được MP3/AAC/M4A trực tiếp, trả HTTP 404 để firmware fallback.
Đừng đăng URL trích xuất công khai: URL thường chứa token có thời hạn.

## Cần chỉnh firmware để dùng thật

- Gửi `X-API-Key` tới API Render ở bước tìm nhạc.
- Nhận `data.url`, `data.ext`, `data.headers`; đưa các header playback hợp lệ
  vào yêu cầu CDN, **không đưa API key Render vào yêu cầu CDN**.
- Player MP3 cũ chỉ xử lý MP3; cần bổ sung AAC/M4A decoder trước khi bật
  các định dạng đó, hoặc fallback ngay khi `ext` không hỗ trợ.
- Coi Direct thành công sau khi giải mã/phát PCM thật; lỗi thì dùng luồng
  mini PC hiện có `stream_pcm`. Không thay đổi wakeword, TFT, MCP hay OTA.

## Giới hạn

- Render Free thường ngủ sau 15 phút không có request, có thể mất khoảng 1 phút
  để chạy lại. ESP32 phải có timeout và fallback mini PC.
- yt-dlp có thể gặp lỗi 403, 429, PO token hoặc ràng buộc IP giữa Render và
  ESP32. API trả URL không đồng nghĩa phát được trên thiết bị khác IP.
- Không có khả năng bypass DRM, chuyển mã HLS, hoặc bảo đảm truy cập tất cả
  bài YouTube/SoundCloud.
